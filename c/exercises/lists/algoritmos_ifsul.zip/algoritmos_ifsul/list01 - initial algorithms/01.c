#include <stdio.h>

int main() {
	int value = 55;
	
	float result = value * 0.3;
	
	printf("%f", result);
	
	return 0;
}

