#include <stdio.h>

int main() {
	int value = 300;
	
	float result = value * 0.15;
	
	printf("%f", result);
	
	return 0;
}

