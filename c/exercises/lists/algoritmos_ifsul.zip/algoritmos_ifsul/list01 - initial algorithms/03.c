#include <stdio.h>

int main() {
	int value = 400;
	
	float result = value * 0.75;
	
	printf("%f", result);
	
	return 0;
}

