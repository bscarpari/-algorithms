#include <stdio.h>

int main() {
  int num;

  scanf("%i", &num);

  if(num > 20)
    printf("\nMaior que 20");

  return 0;
}