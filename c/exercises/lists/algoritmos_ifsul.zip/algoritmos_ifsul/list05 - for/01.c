#include <stdio.h>

/*
  Faça um programa que mostra na tela os
  números de 1 até 100
*/

int main() {
  for (int i = 1; i <= 100; i++)
    printf("%d\n", i);

  return 0;
}