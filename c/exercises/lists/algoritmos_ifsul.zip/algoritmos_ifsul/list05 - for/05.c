#include <stdio.h>

/*
  Faça um programa que mostra os números
  entre 121 e 300
*/

int main() {
  for (int i = 121; i <= 300; i++)
    printf("%d\n", i);

  return 0;
}