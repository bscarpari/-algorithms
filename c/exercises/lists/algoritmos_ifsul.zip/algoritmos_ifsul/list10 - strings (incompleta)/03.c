#include <stdio.h>
#include <string.h>

/* 
	Elabore um algoritmo que l� uma mensagem e criptografa da seguinte maneira: 
	 A - trocar por X 
	 E - trocar por Y 
	 I - trocar por W 
	 O - trocar por K 
	 U - trocar por Z
*/

int main() {
	char input[15], i, length;
	
	length = strlen()
	
	for(int i = 0; i < length; i++) {
		
	}
	
	
	return 0;
}

